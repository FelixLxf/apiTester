#!/usr/bin/python
# -*- coding: UTF-8 -*-

EMAIL_SERVICE = 'smtp.exmail.qq.com'
EMAIL_PORT = 25
