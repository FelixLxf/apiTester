/**
 * Created by pencil1 on 2018/12/10.
 * vuex types
 */

export const LOGIN = 'login';

export const LOGOUT = 'logout';

export const TITLE = 'title';

export const USERNAME = 'userName';

export const ROLES = 'roles';





