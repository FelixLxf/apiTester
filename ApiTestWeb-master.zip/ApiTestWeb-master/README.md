# ApiTestWeb
感觉项目不错的点个star，你的支持是作者源源不断的动力~谢谢！！如有疑问可联系qq：362508572   或q群：700387899 或issue

后端传送门：https://github.com/pencil1/ApiTestManage

线上demo地址：http://47.107.147.188/#/login （账号：ceshi 密码：123456）

## Environment

1. 首先安装  node  版本10以上即可; 确保 node -V
2. 安装 yarn 工具包
3. 命令都是在项目根目录下执行
```
npm install -g yarn


```

## 安装依赖
```
yarn install
```

## Develop 
    yarn serve

## Build
    yarn build

## 登陆地址（ip自己替换）
http://127.0.0.1:8010/#/login

